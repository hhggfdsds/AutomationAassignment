﻿using Common.ApiEndpoints;
using Common;
using NUnit.Framework;
using RestSharp;

namespace AutomationAssignment.TestCases.ApiTests
{
    public class SampleApiTests : APIBaseTest
    {
        private const string testDataPath = @"TestData\ApiTestData\ApiTestsData.json";

        [Test]
        [Category(TestType.NonLiveApiTest)]
        public void Test1()
        {
            RestResponse restResponse = RestActions.Action(ApiEndpoints.GetAll,
                Method.Get);
            ValidateTheAPIExecutionStatus(restResponse);
        }
    }
}
