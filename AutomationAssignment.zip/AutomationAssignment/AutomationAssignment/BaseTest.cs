﻿using CTF.Common;
using CTF.Contracts;
using NUnit.Framework;
using System.IO;
using System.Reflection;
using Common;
using Common.Contracts.Interfaces;
using Common.Standard;

namespace AutomationAssignment
{
    public class BaseTest
    {
        protected ITestData TestData { get; private set; }

        protected IRestActions RestActions { get; private set; }

        protected string Environment { get; private set; }

        protected string SiteType { get; set; }

        protected WebDriverFactory WebDriverFactory { get; private set; }

        [OneTimeSetUp]
        public void BeforeTestRun()
        {
            TestData = new TestData();
            Environment = TestData.TestConfiguration["ApplicationSettings:Env"];
            //Create screenshots directory before the test run.
            CreateANewDirectoryToCaptureScreenshots();
            //Create a new directory for File Downloads
            CreateANewDownloadsDirectory();
        }

        [OneTimeTearDown]
        public void AfterTestRun()
        {
            //Write the required logic to be executed after test run
        }

        [SetUp]
        public void BeforeTest()
        {
            //Launch the Driver
            WebDriverFactory = new WebDriverFactory(TestData);
            TestData.Driver = WebDriverFactory.GetDriver();

            RestActions = new RestActions(TestData);
        }

        [TearDown]
        public void AfterTest()
        {
            //After Test Logic
            if (TestData.Driver != null)
            {
                // Capture the screenshot if exception occurs
                string screenshotPath = BasePage.CaptureScreenshot(TestData);
                TestContext.AddTestAttachment(screenshotPath);

                //Close the current working tab of the browser
                TestData.Driver.Close();
                TestData.Driver.Quit();
            }
        }

        #region Private Methods
        private void CreateANewDirectoryToCaptureScreenshots()
        {
            string current_directory = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location),
                "Screenshots");
            if (!Directory.Exists(current_directory))
            {
                Directory.CreateDirectory(current_directory);
            }
        }

        private void CreateANewDownloadsDirectory()
        {
            string current_directory = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location),
                ApplicationConstants.Downloads);
            if (!Directory.Exists(current_directory))
            {
                Directory.CreateDirectory(current_directory);
            }
        }
        #endregion
    }
}