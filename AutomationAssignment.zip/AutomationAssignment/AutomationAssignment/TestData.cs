﻿using CommonTestFramework.Contracts;
using CTF.Contracts;
using Microsoft.Extensions.Configuration;
using OpenQA.Selenium;

namespace AutomationAssignment
{
    public class TestData : ITestData
    {
        private readonly DataStore _datastore = null;
        private readonly ILog _logger = null;
        private IConfiguration _testConfiguration = null;

        public IConfiguration TestConfiguration
        {
            get
            {
                _testConfiguration ??= new ConfigurationBuilder()
                            .AddJsonFile("appconfig.json")
                            .Build();
                return _testConfiguration;
            }
        }

        public IWebDriver Driver { get; set; }

        public ILog Logger
        {
            get
            {
                var log = _logger ?? new Logger();
                return log;
            }
        }

        public DataStore DataStore
        {
            get
            {
                var store = _datastore ?? new DataStore();
                return store;
            }
        }
    }
}
