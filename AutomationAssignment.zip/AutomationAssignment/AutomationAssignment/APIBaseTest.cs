﻿using Common.Contracts.Interfaces;
using Common.Standard;
using CTF.Contracts;
using FluentAssertions;
using NUnit.Framework;
using RestSharp;
using System.Net;

namespace AutomationAssignment
{
    public class APIBaseTest
    {
        protected IRestActions RestActions { get; private set; }
        protected ITestData TestData { get; private set; }

        [SetUp]
        public void ApiTestSetup()
        {
            TestData = new TestData();
            RestActions = new RestActions(TestData);
        }

        public void ValidateTheAPIExecutionStatus(RestResponse restResponse)
        {
            restResponse.IsSuccessStatusCode.Should().BeTrue("Failed to receive success status code");
            restResponse.ResponseStatus.Should().Be(ResponseStatus.Completed);
            restResponse.StatusCode.Should().Be(HttpStatusCode.OK);
        }
    }
}