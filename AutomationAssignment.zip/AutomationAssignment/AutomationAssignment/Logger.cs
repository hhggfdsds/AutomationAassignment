﻿using CommonTestFramework.Contracts;
using System;

namespace AutomationAssignment
{
    public class Logger : ILog
    {
        public void Log(string message)
        {
            Console.WriteLine(message);
        }
    }
}