﻿using Common.Contracts.Interfaces;
using Common.Enums;

namespace Common.Contracts
{
    public class TestResult : ITestResult
    {
        public ResultStatus Status { get ; set ; }
        public string Name { get; set ; }
        public string ErrorInfo { get ; set; }
    }
}