﻿using Newtonsoft.Json;
using System.IO;
using System.Reflection;
using System.Text;

namespace CommonTestFramework.Contracts
{
    public class DataStore
    {
        public T JsonDataStore<T>(string store_file_path)
        {
            try
            {
                string current_directory = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var file_path = Path.Combine(current_directory, $"{store_file_path}");
                var json_string = File.ReadAllText(file_path,Encoding.UTF8);

                var datamodels = JsonConvert.DeserializeObject<T>(json_string);
                return datamodels;
            }
            catch
            {
                //Could not convert.  Pass back default value...
                var result = default(T);
                return result;
            }
        }

        public T JsonToModel<T>(string jsonValue) where T : class
        {
            try
            {
                var datamodels = JsonConvert.DeserializeObject<T>(jsonValue);
                return datamodels;
            }
            catch
            {
                //Could not convert.  Pass back default value...
                var result = default(T);
                return result;
            }
        }

        public static T GetDataModel<T>(string store_file_path)
        {
            try
            {
                string current_directory = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var file_path = Path.Combine(current_directory, $"{store_file_path}");
                var json_string = File.ReadAllText(file_path, Encoding.UTF8);

                var datamodels = JsonConvert.DeserializeObject<T>(json_string);
                return datamodels;
            }
            catch
            {
                //Could not convert.  Pass back default value...
                var result = default(T);
                return result;
            }
        }

        public string GetFileText(string store_file_path)
        {
            try
            {
                string current_directory = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var file_path = Path.Combine(current_directory, $"{store_file_path}");
                var json_string = File.ReadAllText(file_path, Encoding.UTF8);       
                return json_string;
            }
            catch
            {                
                return string.Empty;
            }
        }

        public string ModelToJson<T>(T model) where T : class
        {
            try
            {
                var jsonValue = JsonConvert.SerializeObject(model);
                return jsonValue;
            }
            catch
            {
                //Could not convert.  Pass back default value...
                var result = string.Empty;
                return result;
            }
        }
    }
}