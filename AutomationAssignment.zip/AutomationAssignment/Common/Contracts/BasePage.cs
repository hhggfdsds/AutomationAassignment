﻿using Common.Custom;
using CTF.Common;
using OpenQA.Selenium;
using System;

namespace CTF.Contracts
{
    public abstract class BasePage
    {
        private readonly By previewResultFrame = By.XPath("//iframe[@id='resultFrame']");
        private readonly By acceptAll = By.XPath("//a[@class='button cookie-accept-all']");

        protected ITestData TestData { get; private set; }

        public readonly SeleniumActions Actions;

        public BasePage(ITestData testData)
        {
            TestData = testData;
            Actions = new SeleniumActions(testData);
        }

        public abstract bool IsPageLoaded();

        public void WaitForPageLoad()
        {
            TestData.Driver.Manage().Timeouts().ImplicitWait
                = TimeSpan.FromSeconds(Convert.ToDouble(TestData.TestConfiguration["Selenium:MaxPageLoadTime"]));
            Actions.WaitForPageLoad();
        }

        public void WaitForFileUpLoad()
        {
            TestData.Driver.Manage().Timeouts().ImplicitWait
                = TimeSpan.FromSeconds(Convert.ToDouble(TestData.TestConfiguration["Selenium:FileDownloadTime"]));
            Actions.WaitForPageLoad();
        }

        public void RefreshPage()
        {
            TestData.Driver.Navigate().Refresh();
        }

        public static string CaptureScreenshot(ITestData testData)
        {
            //Generate the File Path Dynamically and capture the screenshot
            string filePath = Helpers.GenerateARandomScreenshotFilePath() + ".jpeg";
            var captureScreenshot = (testData.Driver as ITakesScreenshot);
            captureScreenshot.GetScreenshot().SaveAsFile(filePath);
            testData.Logger.Log($"Captured the screenshot to {filePath}");
            return filePath;
        }

        public string PageTitle
        {
            get { return TestData.Driver.Title; }
        }

        public void SwitchToWindow(string name)
        {
            Actions.SwitchToWindow(name);
        }

        public bool SwitchToTab(int index)
        {
            return Actions.SwitchToTab(index);
        }

        public T SwitchToPreviewPage<T>() where T: class
        {
            try
            {
                SwitchToTab(1);
                Actions.StaticWait();
                return (T)Activator.CreateInstance(typeof(T), TestData);
            }
            catch(Exception e)
            {
                TestData.Logger.Log(e.Message + e.StackTrace);
                return default;
            }
        }

        public void CloseCurrentTab()
        {
            Actions.CloseTab();
        }

        public void AcceptAllCookies()
        {
            try
            {
                Actions.Click(acceptAll);
            }
            catch
            {
                TestData.Logger.Log("Cookie policy is not set for the site");
            }
        }
    }
}