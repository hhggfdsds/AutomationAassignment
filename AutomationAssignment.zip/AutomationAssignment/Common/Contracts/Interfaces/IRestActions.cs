﻿using RestSharp;
using System.Collections.Generic;

namespace Common.Contracts.Interfaces
{
    public interface IRestActions
    {
        public RestResponse Action(string resource, Method httpMethod);
        public RestResponse Action(string resource, Dictionary<string, string> authHeader, Method httpMethod);
        public RestResponse Action(string resource, Method httpMethod, string body);
        public RestResponse Action(string resource, Method httpMethod, params (string Key, string Value)[] pairs);   
    }
}
