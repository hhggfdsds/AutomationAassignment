﻿namespace CommonTestFramework.Contracts
{
    public interface IReport
    {
        string ReportName { get; }

        void GenerateReport(string name, string format);
    }
}