﻿using Common.Enums;

namespace Common.Contracts.Interfaces
{
    public interface ITestResult
    {
       public ResultStatus Status { get; set; }
       public string Name { get; set; }
       public string ErrorInfo { get; set; }
    }
}