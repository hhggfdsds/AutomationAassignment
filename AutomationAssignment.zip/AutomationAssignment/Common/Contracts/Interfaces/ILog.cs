﻿namespace CommonTestFramework.Contracts
{
    public interface ILog
    {
        public void Log(string message);
    }
}