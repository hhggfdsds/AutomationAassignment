﻿using CommonTestFramework.Contracts;
using Microsoft.Extensions.Configuration;
using OpenQA.Selenium;

namespace CTF.Contracts
{
    public interface ITestData
    {
        IConfiguration TestConfiguration { get; }

        IWebDriver Driver { get; set; }

        ILog Logger { get; }

        DataStore DataStore { get; }
    }
}