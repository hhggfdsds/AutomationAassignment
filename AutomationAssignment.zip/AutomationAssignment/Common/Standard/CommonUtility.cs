﻿using CommonTestFramework.Contracts;
using System;

namespace CommonTestFramework.Common
{
    public class CommonUtility
    {
        private readonly ILog log;

        public CommonUtility(ILog log)
        {
            this.log = log;
        }

        public bool TryCatch(Action action)
        {
            try
            {
                action();
                return true;
            }
            catch (Exception ex)
            {
                log.Log(ex.Message + "<br />" + ex.StackTrace);
                return false;
            }
        }
    }
}
