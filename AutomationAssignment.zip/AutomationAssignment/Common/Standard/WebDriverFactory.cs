﻿using Common.Custom;
using Common.Standard;
using CTF.Contracts;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Remote;
using RestSharp;
using System;
using System.Collections.Generic;
using WebDriverManager;
using WebDriverManager.DriverConfigs.Impl;

namespace CTF.Common
{
    public class WebDriverFactory
    {
        private readonly bool is_grid_enabled;
        private readonly string grid_url;
        private readonly string browser;
        private readonly string browser_Version;
        private readonly double page_load_time;
        private readonly bool isSSLError;
        private readonly ITestData testData;
        private readonly int gridTimeOut;

        public string SeleniumGridCurrentSessionGUID { get; private set; }
        public string SeleniumGridCurrentNodeGUID { get; private set; }
        public string NodeURI { get; private set; }

        public WebDriverFactory(ITestData testData)
        {
            this.testData = testData;
            is_grid_enabled = Convert.ToBoolean(testData.TestConfiguration["Selenium:SeleniumGridEnabled"]);
            grid_url = testData.TestConfiguration["Selenium:SeleniumGridUrl"];
            browser = testData.TestConfiguration["Selenium:Browser"];
            browser_Version = testData.TestConfiguration["Selenium:Browser_Version"];
            page_load_time = Convert.ToDouble(testData.TestConfiguration["Selenium:MaxPageLoadTime"]);
            gridTimeOut = Convert.ToInt32(testData.TestConfiguration["Selenium:SeleniumGridTime"]);
            isSSLError = Convert.ToBoolean(testData.TestConfiguration["Selenium:IgnoreSSLError"]);
        }

        public IWebDriver GetDriver()
        {
            return browser.ToLower() switch
            {
                "chrome" => GetChromeDriver(),
                "edge" => GetEdgeDriver(),
                _ => throw new Exception($"The specified browser '{browser}' is not supported"),
            };
        }

        public RestResponse DrainTheCurrentUsedNode()
        {
            if (SeleniumGridCurrentNodeGUID != null)
            {
                string nodeDrainEndpoint = $"{grid_url}se/grid/distributor/node/{SeleniumGridCurrentNodeGUID}/drain";

                RestActions restActions = new RestActions(grid_url);
                Dictionary<string, string> headers = new Dictionary<string, string>()
                {
                    {"X-REGISTRATION-SECRET","" }
                };
                RestResponse restResponse = restActions.Action(nodeDrainEndpoint, headers, Method.Post);
                return restResponse;
            }
            else { throw new Exception("Failed to Drain the Current Node (container)"); }
        }

        private IWebDriver GetChromeDriver()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArguments("--incognito");
            options.AddArgument("no-sandbox");
            if (isSSLError)
            {
                options.AddArgument("ignore-certificate-errors");
            }
            options.AddUserProfilePreference("download.default_directory", Helpers.GetDownloadsFolderPath());
            IWebDriver driver;
            if (!is_grid_enabled)
            {
                new DriverManager().SetUpDriver(new ChromeConfig(), browser_Version);
                driver = new ChromeDriver(options);
                driver.Manage().Window.Maximize();
            }
            else
            {
                driver = GetChromeRemoteDriver();
            }
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(page_load_time);
            return driver;
        }

        private IWebDriver GetEdgeDriver()
        {
            EdgeOptions options = new EdgeOptions();
            options.AddArgument("InPrivate");
            options.AddArgument("no-sandbox");
            options.AddUserProfilePreference("download.default_directory", Helpers.GetDownloadsFolderPath());
            IWebDriver driver;
            if (!is_grid_enabled)
            {
                new DriverManager().SetUpDriver(new EdgeConfig(), browser_Version);
                driver = new EdgeDriver(options);
                driver.Manage().Window.Maximize();
            }
            else
            {
                driver = GetEdgeRemoteDriver();
            }
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(page_load_time);
            return driver;
        }

        private IWebDriver GetChromeRemoteDriver()
        {
            DriverOptions driverOptions = new ChromeOptions();
            var driver = new RemoteWebDriver(new Uri(grid_url), driverOptions);
            driver.Manage().Window.Maximize();
            return driver;
        }

        private IWebDriver GetEdgeRemoteDriver()
        {
            DriverOptions driverOptions = new EdgeOptions();
            var driver = new RemoteWebDriver(new Uri(grid_url), driverOptions);
            driver.Manage().Window.Maximize();
            return driver;
        }
    }
}
