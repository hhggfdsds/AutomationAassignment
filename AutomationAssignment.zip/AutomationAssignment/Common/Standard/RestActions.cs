﻿using Common.Contracts.Interfaces;
using CTF.Contracts;
using RestSharp;
using System.Collections.Generic;

namespace Common.Standard
{
    public class RestActions : IRestActions
    {
        private readonly RestClient restClient;

        public RestActions(ITestData testData)
        {
            string ocelotGateway = testData.TestConfiguration["ApiSettings:OcelotUrl"];
            string apiToken = testData.TestConfiguration["ApiSettings:APIToken"];
            var client = new RestClient(ocelotGateway)
            {
                AcceptedContentTypes = new string[] { "application/json" }
            };
            client.AddDefaultHeader("Authorization", apiToken);
            restClient = client;
        }

        public RestActions(string endPoint)
        {
            var client = new RestClient(endPoint)
            {
                AcceptedContentTypes = new string[] { "application/json" }
            };
            restClient = client;
        }

        public RestResponse Action(string resource, Method httpMethod)
        {
            RestRequest request = new RestRequest(resource, httpMethod);
            return ExecuteRequest(request);
        }

        public RestResponse Action(string resource, Dictionary<string, string> authHeader, Method httpMethod)
        {
            RestRequest request = new RestRequest(resource, httpMethod);
            foreach (var item in authHeader)
            {
                request.AddHeader(item.Key, item.Value);
            }
            return ExecuteRequest(request);
        }

        public RestResponse Action(string resource, Method httpMethod, string jsonBody)
        {
            RestRequest request = new RestRequest(resource, httpMethod);
            request.AddBody(jsonBody);
            return ExecuteRequest(request);
        }

        public RestResponse Action(string resource, Method httpMethod, params (string Key, string Value)[] pairs)
        {
            RestRequest request = new RestRequest(resource, httpMethod);
            foreach (var (Key, Value) in pairs)
            {
                request.AddQueryParameter(Key, Value);
            }
            return ExecuteRequest(request);
        }

        private RestResponse ExecuteRequest(RestRequest request)
        {
            RestResponse restResponse = restClient.Execute(request);
            return restResponse;
        }
    }
}