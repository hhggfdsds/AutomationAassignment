﻿using CommonTestFramework.Common;
using CommonTestFramework.Contracts;
using CTF.Contracts;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace CTF.Common
{
    public class SeleniumActions
    {
        private readonly IWebDriver driver;
        private readonly double page_load_time;
        private readonly double element_wait_time;
        private readonly double staticWait;
        private readonly ILog logger;
        private readonly CommonUtility Common;

        public SeleniumActions(ITestData testData)
        {
            Common = new CommonUtility(testData.Logger);

            logger = testData.Logger;
            driver = testData.Driver;
            page_load_time = Convert.ToDouble(testData.TestConfiguration["Selenium:MaxPageLoadTime"]);
            staticWait = Convert.ToDouble(testData.TestConfiguration["Selenium:StaticWait"]);
            element_wait_time = Convert.ToInt32(testData.TestConfiguration["Selenium:ElementWaitTime"]);
        }

        public void StaticWait()
        {
            Thread.Sleep(TimeSpan.FromSeconds(staticWait));
        }

        /// <summary>
        /// Click on the required locator
        /// </summary>
        /// <param name="locator">Locator</param>
        public bool Click(By locator)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            bool flag = Common.TryCatch(() =>
            {
                //Wait till the elememt is loaded and perform Click operation
                wait.Until(x => x.FindElement(locator).Displayed);
                IWebElement element = driver.FindElement(locator);
                element.Click();
                logger.Log($"Clicked on the Locator with criteria => {locator.Criteria}");
            });
            return flag;
        }

        /// <summary>
        /// Click on the required locator
        /// </summary>
        /// <param name="locator">Locator</param>
        public bool Click(By locator, int index)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            bool flag = Common.TryCatch(() =>
            {
                //Wait till the elememt is loaded and perform Click operation
                wait.Until(x => x.FindElement(locator).Displayed);
                var element = driver.FindElements(locator)[index];
                element.Click();
                logger.Log($"Clicked on the Locator with criteria => {locator.Criteria}");
            });
            return flag;
        }

        public object ExecuteJavaScript(string script)
        {
            object element = null;
            bool flag = Common.TryCatch(() =>
            {
                IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                element = js.ExecuteScript(script);
            });
            if (flag) { return element; } else { return null; }
        }

        public bool UpdateAttribute(string locator, string attributeName, string newAttributeValue)
        {
            bool flag = Common.TryCatch(() =>
            {
                IWebElement element = GetElementByName(locator) as IWebElement;
                IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                js.ExecuteScript("arguments[0].setAttribute(arguments[1], arguments[2]);",
                    element, attributeName, newAttributeValue);
            });
            return flag;
        }

        public bool ClickElementUsingJavaScript(By locator)
        {
            bool flag = Common.TryCatch(() =>
            {
                var element = driver.FindElement(locator);
                IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                js.ExecuteScript("arguments[0].click();", element);
            });
            return flag;
        }

        public object GetElementByName(string locatorName)
        {
            object element = null;
            bool flag = Common.TryCatch(() =>
            {
                element = ExecuteJavaScript($"return document.getElementsByName('{locatorName}')[0]");
            });
            if (flag) { return element; } else { return null; }
        }

        /// <summary>
        /// Wait for all the elements to load and click on the required element
        /// </summary>
        /// <param name="locator">Locator</param>
        /// <param name="text">Matching Text to perform click</param>
        public bool Click(By locator, string text)
        {
            IsElementDisplayed(locator);
            bool flag = Common.TryCatch(() =>
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
                var elements = driver.FindElements(locator);
                IWebElement requiredElement = elements
                    .Where(x => x.Text.Contains(text))
                    .Select(x => x).FirstOrDefault();
                requiredElement.Click();
                logger.Log($"Clicked on {text}");
            });
            return flag;
        }

        public bool ClickLast(By locator)
        {
            IsElementDisplayed(locator);
            bool flag = Common.TryCatch(() =>
            {
                var elements = driver.FindElements(locator);
                elements.Last().Click();
            });
            return flag;
        }

        /// <summary>
        /// Hover the mouse on the Locator
        /// </summary>
        /// <param name="locator">Locator</param>
        public bool HoverOnElement(By locator)
        {
            var flag = IsElementDisplayed(locator);
            if (flag)
            {
                return Common.TryCatch(() =>
                {
                    //Creating object of an Actions class
                    Actions action = new Actions(driver);

                    //Performing the mouse hover action on the target element.
                    action.MoveToElement(driver.FindElement(locator)).Perform();
                });
            }
            else
            {
                return flag;
            }
        }

        public bool SendKeys(By locator, string text_to_enter)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            var flag = Common.TryCatch(() =>
            {
                //Wait till the elememt is loaded and perform Click operation
                wait.Until(x => x.FindElement(locator).Displayed);
                driver.FindElement(locator).SendKeys(text_to_enter);
                logger.Log($"Entered value {text_to_enter} to locator => {locator.Criteria}");
            });
            return flag;
        }

        public bool SendKeys(By locator, int elementIndex, string text_to_enter)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            var flag = Common.TryCatch(() =>
            {
                //Wait till the elememts are loaded
                wait.Until(x => x.FindElements(locator).Count > 0);
                var element = driver.FindElements(locator)[elementIndex];
                element.SendKeys(text_to_enter);
                logger.Log($"Entered value {text_to_enter} to locator => {locator.Criteria}");
            });
            return flag;
        }

        public bool IsElementDisplayed(By locator)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            bool flag = false;
            Common.TryCatch(() =>
            {
                //Check if the element is displayed
                flag = wait.Until(x => x.FindElement(locator).Displayed);
                logger.Log($"The locator status for => {locator.Criteria} is {flag}");
            });
            return flag;
        }

        public int GetElementsCount(By locator)
        {
            int count = 0;
            bool flag = Common.TryCatch(() =>
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
                count = wait.Until(x => x.FindElements(locator)).Count;
            });
            return count;
        }

        public bool IsElementDisplayedWithText(By locator)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            StaticWait();
            Common.TryCatch(() =>
            {
                //Check if the element is displayed
                var element = wait.Until(x => x.FindElement(locator).Displayed
                & x.FindElement(locator).Text != string.Empty);
                logger.Log($"Check the locator => {locator.Criteria} is displayed with text");
            });
            IWebElement element = wait.Until(x => x.FindElement(locator));
            return element.Displayed;
        }

        public bool IsElementsDisplayedWithText(By locator, string textToCheck)
        {
            IsElementDisplayedWithText(locator);
            var elementsTexts = driver.FindElements(locator).Select(x => x.Text).ToList();
            return elementsTexts.Where(x => x.ToLower().Contains(textToCheck.ToLower())).Select(x => x.ToLower().Contains(textToCheck.ToLower())).FirstOrDefault();
        }

        public bool IsElementsDisplayed(By locator)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            bool flag = false;
            Common.TryCatch(() =>
            {
                //Check if the element is displayed
                flag = wait.Until(x => x.FindElements(locator).Count > 0);
                logger.Log($"Elements are dislpayed for the locator => {locator.Criteria}");
            });
            return flag;
        }

        public bool IsElementTextDisplayed(By locator, string textToCheck)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            Common.TryCatch(() =>
            {
                //Check if the element is displayed
                var element = wait.Until(x => x.FindElement(locator).Text.Contains(textToCheck));
                logger.Log($"Check if the locator is => {locator.Criteria} displayed with text {textToCheck}");
            });
            IWebElement element = wait.Until(x => x.FindElement(locator));
            return element.Displayed;
        }

        public bool SelectDropdown(By locator, string value_to_select)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            var flag = Common.TryCatch(() =>
            {
                //Select a value in the dropdown
                IWebElement element = wait.Until(x => x.FindElement(locator));
                SelectElement selectElement = new SelectElement(element);
                selectElement.SelectByText(value_to_select);
                logger.Log($"Select the dropdown in the locator => {locator.Criteria}");
            });
            return flag;
        }

        public List<string> GetDropdownValues(By locator)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            List<string> dropDownOptions = null;
            Common.TryCatch(() =>
            {
                //Select a value in the dropdown
                IWebElement element = wait.Until(x => x.FindElement(locator));
                SelectElement selectElement = new SelectElement(element);
                wait.Until(x => selectElement.Options.Count >= 1);
                dropDownOptions = selectElement.Options.Select(x => x.Text).ToList();
                logger.Log($"Select the dropdown in the locator => {locator.Criteria}");
            });
            return dropDownOptions;
        }

        public string GetDropdownText(By locator)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            //Select a value in the dropdown
            IWebElement element = wait.Until(x => x.FindElement(locator));
            SelectElement selectElement = new SelectElement(element);
            string dropDownSelected = selectElement.SelectedOption.Text;
            logger.Log($"Select dropdown value is {dropDownSelected} in the locator => {locator.Criteria}");
            return dropDownSelected;
        }

        public bool SelectDropdownbyIndex(By locator, int index)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            var flag = Common.TryCatch(() =>
            {
                //Select a value in the dropdown
                IWebElement element = wait.Until(x => x.FindElement(locator));
                SelectElement selectElement = new SelectElement(element);
                selectElement.SelectByIndex(index);
                logger.Log($"Select the dropdown in the locator with index => {locator.Criteria}");
            });
            return flag;
        }

        public string GetElementText(By locator)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            bool is_displayed = IsElementDisplayed(locator);
            if (is_displayed)
            {
                //Get the element Text
                IWebElement element = wait.Until(x => x.FindElement(locator));
                logger.Log($"Get text from locator => {locator.Criteria}");
                return element.Text;
            }
            else
            {
                return string.Empty;
            }
        }

        public List<string> GetElementsText(By locator)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            bool is_displayed = IsElementDisplayed(locator);
            if (is_displayed)
            {
                //Get the element Text
                var elementTexts = wait.Until(x => x.FindElements(locator)).Select(x => x.Text).ToList();
                return elementTexts;
            }
            else
            {
                return null;
            }
        }

        public bool WaitForPageLoad()
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            return Common.TryCatch(() =>
            {
                //Wiat for the page to load
                var page_wait = new WebDriverWait(driver, TimeSpan.FromSeconds(page_load_time));
                wait.Until(driver => (driver as IJavaScriptExecutor).ExecuteScript("return document.readyState;"));
                logger.Log($"Waited till the page is loaded");
            });
        }

        public bool SwitchToTab(int index)
        {
            return Common.TryCatch(() =>
            {
                driver.SwitchTo().Window(driver.WindowHandles[index]);
            });
        }

        public bool SwitchToLastTab()
        {
            return Common.TryCatch(() =>
            {
                driver.SwitchTo().Window(driver.WindowHandles.Last());

            });
        }

        public int GetTabCount()
        {
            return driver.WindowHandles.Count();
        }

        public bool SwitchToWindow(string name)
        {
            return Common.TryCatch(() =>
            {
                driver.SwitchTo().Window(name);
            });
        }

        public bool SwitchToFrame(By locator)
        {
            return Common.TryCatch(() =>
            {
                IWebElement frame = driver.FindElement(locator);
                driver.SwitchTo().Frame(frame);
            });
        }

        public bool SwitchToDefaultContent()
        {
            return Common.TryCatch(() =>
            {
                driver.SwitchTo().DefaultContent();
            });
        }

        public bool SwitchToAlert()
        {
            return Common.TryCatch(() =>
            {
                IAlert alert = driver.SwitchTo().Alert();
                alert.Accept();
            });
        }

        public bool WaitForPageTitle(string pageName)
        {
            return Common.TryCatch(() =>
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(page_load_time));
                wait.Until(x => x.Title.Contains(pageName));
            });
        }

        public bool WaitForTextInURL(string pageID)
        {
            return Common.TryCatch(() =>
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(page_load_time));
                bool flag = wait.Until(x => x.Url.Contains(pageID));
            });
        }

        public string GetElementAttribute(By locator, string attribute)
        {
            bool flag = IsElementDisplayed(locator);
            if (flag)
            {
                var elementAttribute = driver.FindElement(locator).GetAttribute(attribute);
                return elementAttribute;
            }
            else { return string.Empty; }
        }

        public string GetHiddenElementAttribute(By locator, string attribute)
        {
            var elementAttribute = driver.FindElement(locator).GetAttribute(attribute);
            return elementAttribute;
        }

        public string GetCurrentUrl()
        {
            string currentUrl = driver.Url.ToString();
            return currentUrl;
        }

        public bool NavigateToPreviousPage()
        {
            return Common.TryCatch(() =>
            {
                driver.Navigate().Back();
            });
        }

        public bool Clear(By locator)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            var flag = Common.TryCatch(() =>
            {
                //Wait till the elememt is loaded and perform Click operation
                IWebElement element = wait.Until(x => x.FindElement(locator));
                element.Clear();
                logger.Log($"Clear the textbox => {locator.Criteria}");
            });
            return flag;
        }

        public bool Clear(By locator, int index)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            var flag = Common.TryCatch(() =>
            {
                //Wait till the elememt is loaded and perform Click operation
                var elements = driver.FindElements(locator);
                elements[index].Clear();
                logger.Log($"Clear the textbox => {locator.Criteria}");
            });
            return flag;
        }

        public bool CloseTab()
        {
            return Common.TryCatch(() =>
            {
                driver.Close();
                driver.SwitchTo().Window(driver.WindowHandles[0]);
            });
        }

        public bool OpenNewTab()
        {
            return Common.TryCatch(() =>
            {
                ((IJavaScriptExecutor)driver).ExecuteScript("window.open();");
                driver.SwitchTo().Window(driver.WindowHandles.Last());
            });
        }

        public bool NavigateToUrl(string url)
        {
            return Common.TryCatch(() =>
            {
                driver.Navigate().GoToUrl(url);
            });
        }

        public bool IsElementEnabled(By locator)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(element_wait_time));
            bool flag = false;
            Common.TryCatch(() =>
            {
                //Check if the element is displayed
                flag = wait.Until(x => x.FindElement(locator).Enabled);
                logger.Log($"The locator status for => {locator.Criteria} is {flag}");
            });
            return flag;
        }
    }
}