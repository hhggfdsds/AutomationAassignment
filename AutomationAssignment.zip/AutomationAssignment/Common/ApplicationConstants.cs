﻿namespace Common
{
    public class ApplicationConstants
    {
        public const string Downloads = "Downloads";
    }
}
