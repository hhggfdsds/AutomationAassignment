﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;

namespace Common.Custom
{
    public static class Helpers
    {
        public static string GenerateARandomScreenshotFilePath()
        {
            string randomString = RandomString + "_" + DateTime.Now.ToString("MMddyyyy_HHmmss");
            string current_directory = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            var file_path = Path.Combine(current_directory, $"Screenshots\\{randomString}");
            return file_path;
        }

        public static string GetDownloadsFolderPath()
        {
            string current_directory = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            var file_path = Path.Combine(current_directory, ApplicationConstants.Downloads);
            return file_path;
        }

        public static string RandomString
        {
            get
            {
                Random random = new Random();
                const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                return new string(Enumerable.Repeat(chars, 15)
                    .Select(s => s[random.Next(s.Length)]).ToArray());
            }
        }

        public static string RandomHyphenatedNames
        {
            get
            {
                Random random = new Random();
                int number = random.Next(999);
                string hyphenatedName = "first" + number + "-last";
                return hyphenatedName;                
            }
        }

        public static string RandomEmail
        {
            get
            {
                Random random = new Random();
                const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                string randomString = new string(Enumerable.Repeat(chars, 15)
                    .Select(s => s[random.Next(s.Length)]).ToArray());
                return "rt_" + randomString.ToLower() + "@" + "wvi.test.com";
            }
        }
        public static string RandomPhoneNumber
        {
            get
            {
                Random random = new Random();
                const string chars = "0123456789";
                string randomString = new string(Enumerable.Repeat(chars, 10)
                    .Select(s => s[random.Next(s.Length)]).ToArray());
                return randomString;
            }
        }
        public static string RandboxNumbers
        {
            get
            {
                Random random = new Random();
                const string chars = "0123456789";
                string randomString = new string(Enumerable.Repeat(chars, 3)
                    .Select(s => s[random.Next(s.Length)]).ToArray());
                return randomString;
            }
        }
        
        public static string RandomId
        {
            get
            {
                Random random = new Random();
                const string chars = "0123456789";
                string randomString1 = new string(Enumerable.Repeat(chars, 6)
                    .Select(s => s[random.Next(s.Length)]).ToArray());
                string randomString2 = new string(Enumerable.Repeat(chars, 4)
                    .Select(s => s[random.Next(s.Length)]).ToArray());
                return "CAM"+"-"+randomString1+"-"+randomString2;
            }
        }

        public static string RandomThaiCharacters
        {
            get
            {
                Random random = new Random();
                int number = random.Next(999);
                string thaiName = "อันดับแรก" + number + "ล่าสุด";
                return thaiName;
            }
        }

        public static string RandomSpecialCharacter
        {
            get
            {
                Random random = new Random();
                const string chars = "!@#$%^&*~";
                string randomString = new string(Enumerable.Repeat(chars, 4)
                    .Select(s => s[random.Next(s.Length)]).ToArray());
                return randomString;
            }
        }
    }
}
