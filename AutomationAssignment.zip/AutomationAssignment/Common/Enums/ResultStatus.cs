﻿namespace Common.Enums
{
    public enum ResultStatus
    {
        PASS,
        FAIL,
        INCONCLUSIVE
    }
}