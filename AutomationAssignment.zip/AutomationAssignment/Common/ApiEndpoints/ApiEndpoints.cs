﻿namespace Common.ApiEndpoints
{
    public class ApiEndpoints
    {
        #region Endpoints
        public const string ListAllPonds = "pond";
        public const string GetOnePond = "pond/:pondId";
        public const string CreatePond = "pond";
        public const string UpdatePond = "pond/:pondId";
        public const string DeletePond = "pond/:pondId";
        public const string ListAllFishInAPond = "pond/:pondId/fish";
        public const string GetOneFishInAPond = "pond/:pondId/fish/:fishId";
        public const string CreateFish = "pond/:pondId/fish";
        public const string UpdateFish = "pond/:pondId/fish/:fishId";
        public const string DeleteFish = "pond/:pondId/fish/:fishId";
        #endregion
    }
}