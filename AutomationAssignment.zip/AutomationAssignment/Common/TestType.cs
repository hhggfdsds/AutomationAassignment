﻿namespace Common
{
    public class TestType
    {
        public const string Smoke = "Smoke";
        public const string All = "All";
        public const string Regression = "Regression";
        public const string Umbraco = "Umbraco";
        public const string FrontEnd = "FrontEnd";
        public const string Live = "Live";
        public const string NonLive = "NonLive";
        public const string Master = "Master";
        public const string France = "France";
        public const string Sandbox = "Sandbox";
        public const string Staging = "Staging";
        public const string U4Admin = "U4Admin";
        public const string IreLand = "IreLand";
        public const string Finland = "FinLand";
        public const string LiveApiTest = "LiveApiTest";
        public const string NonLiveApiTest = "NonLiveApiTest";
        public const string UK = "UK";
        public const string Spain = "Spain";
        public const string SouthAfrica = "SouthAfrica";
        public const string Thailand = "Thailand";
        public const string RetentionSmoke = "RetentionSmoke";
        public const string Retention = "Retention";
        public const string LiveSite = "LiveSite";
        public const string PreLive = "PreLive";
    }
}